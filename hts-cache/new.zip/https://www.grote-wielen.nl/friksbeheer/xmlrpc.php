<!doctype html>
<html lang="nl" prefix="og: http://ogp.me/ns#">
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
      <link rel="shortcut icon" href="" />
  <link rel="pingback" href="https://www.grote-wielen.nl/friksbeheer/xmlrpc.php" />
  <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet"> 
  <title> - Restaurant De Grote Wielen</title>
  
<!-- This site is optimized with the Yoast SEO plugin v6.3.1 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="nl_NL" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Pagina niet gevonden - Restaurant De Grote Wielen" />
<meta property="og:site_name" content="Restaurant De Grote Wielen" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="Pagina niet gevonden - Restaurant De Grote Wielen" />
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/www.grote-wielen.nl\/","name":"Restaurant De Grote Wielen","potentialAction":{"@type":"SearchAction","target":"https:\/\/www.grote-wielen.nl\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.grote-wielen.nl\/friksbeheer\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.10"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='frix-setup-css'  href='https://www.grote-wielen.nl/friksbeheer/wp-content/plugins/frix-setup/public/css/frix-setup-public.css?ver=1.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='frx-normalize-css'  href='https://www.grote-wielen.nl/friksbeheer/wp-content/themes/frix-template-standard/css/normalize.css?ver=1.1' type='text/css' media='all' />
<link rel='stylesheet' id='frx-awesome-css'  href='https://www.grote-wielen.nl/friksbeheer/wp-content/themes/frix-template-standard/css/font-awesome.min.css?ver=1.1' type='text/css' media='all' />
<link rel='stylesheet' id='frx-style-css'  href='https://www.grote-wielen.nl/friksbeheer/wp-content/themes/frix-template-standard/style.css?ver=4.9.10' type='text/css' media='all' />
<link rel='stylesheet' id='frx-colors-css'  href='https://www.grote-wielen.nl/friksbeheer/wp-content/themes/frix-template-standard/css/colors.php?ver=4.9.10' type='text/css' media='all' />
<script type='text/javascript' src='https://www.grote-wielen.nl/friksbeheer/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://www.grote-wielen.nl/friksbeheer/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://www.grote-wielen.nl/friksbeheer/wp-content/plugins/frix-setup/public/js/frix-setup-public.js?ver=1.0.6'></script>
<script type='text/javascript' src='https://www.grote-wielen.nl/friksbeheer/wp-content/themes/frix-template-standard/js/jquery.easing.min.js?ver=4.9.10'></script>
<script type='text/javascript' src='https://www.grote-wielen.nl/friksbeheer/wp-content/themes/frix-template-standard/js/jquery.bxslider.min.js?ver=4.9.10'></script>
<script type='text/javascript' src='https://www.grote-wielen.nl/friksbeheer/wp-content/themes/frix-template-standard/js/slick.min.js?ver=4.9.10'></script>
<script type='text/javascript' src='https://www.grote-wielen.nl/friksbeheer/wp-content/themes/frix-template-standard/js/jquery.matchHeight-min.js?ver=4.9.10'></script>
<script type='text/javascript' src='https://www.grote-wielen.nl/friksbeheer/wp-content/themes/frix-template-standard/js/functions.js?ver=4.9.10'></script>
<link rel='https://api.w.org/' href='https://www.grote-wielen.nl/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.grote-wielen.nl/friksbeheer/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.grote-wielen.nl/friksbeheer/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.10" />
  <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-39988609-46', 'grote-wielen.nl');
  ga('set', 'anonymizeIp', true);
  ga('send', 'pageview');
  </script>

  <script id="Cookiebot" src="https://consent.cookiebot.com/uc.js" data-cbid="7fffc248-697c-4046-90ac-88697c2fbfec" type="text/javascript" async></script>

</head>
<body class="error404">
	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/nl_NL/sdk.js#xfbml=1&version=v2.4&appId=231306713576846";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>
	<div class="header header--choice-2">
									<div class="header__upper">
				<div class="container clearfix">
					<div class="table">
					<div class="table__cell">
						<a href="https://www.grote-wielen.nl/"><img class="logo"  src="https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2017/12/logo-groteiwelen.png" /></a>
						<a class="phone" href="tel:0511-431777"><i class="fa fa-phone frx_c_s " aria-hidden="true"></i>0511-431777</a>	
					</div>
					<div class="table__cell table__cell--right">
						<div class="clearfix class-inline"><ul id="menu-top-menu" class="menu"><li id="menu-item-686" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-686"><a href="https://www.grote-wielen.nl/over-ons/">Over ons</a></li>
<li id="menu-item-537" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-537"><a href="https://www.grote-wielen.nl/openingstijden/">Openingstijden</a></li>
<li id="menu-item-262" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-262"><a href="https://www.grote-wielen.nl/contact/">Contact</a></li>
</ul></div>						<a class="btn btn--secu btn--arrow" href="https://www.grote-wielen.nl/contact/">Offerte aanvragen</a>
					</div>
					
					</div>
				</div>
			</div>
			<div class="header__lower frx_bg_p">
				<div class="container clearfix">
					<div class="table">
						<div id="nav-icon2">
							<span></span>
							<span></span>
							<span></span>
							<span></span>
							<span></span>
							<span></span>
						</div>
						<div class="menu__holder table__cell"><div class="menu-hoofd-menu-container"><ul id="menu-hoofd-menu" class="menu"><li id="menu-item-688" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-688"><a href="https://www.grote-wielen.nl/">Home</a></li>
<li id="menu-item-484" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-484"><a href="/eten-en-drinken/">Eten en drinken</a>
<ul class="sub-menu">
	<li id="menu-item-864" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-864"><a href="https://www.grote-wielen.nl/eten-en-drinken/a-la-carte/">A la Carte</a></li>
	<li id="menu-item-865" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-865"><a href="https://www.grote-wielen.nl/eten-en-drinken/onze-menus/">Onze Menu&#8217;s</a></li>
	<li id="menu-item-860" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-860"><a href="https://www.grote-wielen.nl/eten-en-drinken/tafelbarbecue/">Tafelbarbeque</a></li>
	<li id="menu-item-862" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-862"><a href="https://www.grote-wielen.nl/eten-en-drinken/buffetten/">Buffetten</a></li>
	<li id="menu-item-861" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-861"><a href="https://www.grote-wielen.nl/eten-en-drinken/koffietafel/">Koffietafel</a></li>
	<li id="menu-item-863" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-863"><a href="https://www.grote-wielen.nl/eten-en-drinken/high-tea/">High Tea</a></li>
</ul>
</li>
<li id="menu-item-238" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-238"><a href="https://www.grote-wielen.nl/vergaderen/">Vergaderen</a></li>
<li id="menu-item-237" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-237"><a href="https://www.grote-wielen.nl/jachthaven/">Jachthaven</a></li>
<li id="menu-item-685" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-685"><a href="https://www.grote-wielen.nl/jachthaven/bootverhuur/">Bootverhuur</a></li>
<li id="menu-item-234" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-234"><a href="https://www.grote-wielen.nl/chaletverhuur/">Chaletverhuur</a></li>
<li id="menu-item-479" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-479"><a href="/activiteiten">Activiteiten</a></li>
<li id="menu-item-236" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-236"><a href="https://www.grote-wielen.nl/feesten/">Feesten</a></li>
</ul></div></div>
						<!--<div class="table__cell table__cell--right"><a class="loop"><i class="fa fa-search" aria-hidden="true"></i></a></div>-->
					</div>	
				</div>
			</div>
			</div>
	
	<div class="container">
        <h1>404 Error: Pagina niet gevonden</h1>  
        <h2>Pagina niet gevonden</h2>
        <p>De door u opgevraagde pagina werd helaas niet gevonden.</p>
        <p>Mogelijk is de pagina verwijderd of heeft u op een verouderde link geklikt.</p>
        <p>Klik <a href="/">hier</a> om naar onze homepagina te gaan.</p>
	</div>
<div class="footer bg-grey">
	<div class="container clearfix">
		<div class="footer__block left">
			<h2 class="title title--footer">Direct contact</h2>
			<p><p>Neem vrijblijvend contact met ons op</p>
</p>
			<a class="mail_link" href="tel:0511-431777"><i class="fa fa-phone frx_c_p" aria-hidden="true"></i>0511-431777</a>
			<a class="mail_link" href="mailto:info@grote-wielen.nl"><i class="fa fa-envelope-o frx_c_p" aria-hidden="true"></i>info@grote-wielen.nl</a>
			<br /> 
			<a href="https://www.grote-wielen.nl/contact/" class="btn btn--prim btn--arrow">Contact opnemen</a>
		</div>
		<div class="footer__block footer__block--middle left">
			<h2 class="title title--footer">Dit hebben we</h2>
										<ul>
				    				        				        <li>
				            <a href="https://www.grote-wielen.nl/eten-en-drinken2/">Eten en drinken</a>
				        </li>
				    				        				        <li>
				            <a href="https://www.grote-wielen.nl/jachthaven/">Jachthaven</a>
				        </li>
				    				        				        <li>
				            <a href="https://www.grote-wielen.nl/vergaderen/">Vergaderen</a>
				        </li>
				    				        				        <li>
				            <a href="https://www.grote-wielen.nl/virtuele-tour/">Virtuele tour</a>
				        </li>
				        			</ul>
									</div>
		<div class="footer__block left">
			<h2 class="title title--footer">U vindt bij ons:</h2>
			<p><img class="wp-image-551 alignnone" src="http://template.friks.it/friksbeheer/wp-content/uploads/2018/01/aed-pictogrammen_2411_350x400-263x300.png" alt="" width="56" height="64" srcset="https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/aed-pictogrammen_2411_350x400-263x300.png 263w, https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/aed-pictogrammen_2411_350x400-114x130.png 114w, https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/aed-pictogrammen_2411_350x400.png 350w" sizes="(max-width: 56px) 100vw, 56px" /> <img class="alignnone wp-image-552" src="http://template.friks.it/friksbeheer/wp-content/uploads/2018/01/anwb-logo-groot-300x188.png" alt="" width="102" height="64" srcset="https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/anwb-logo-groot-300x188.png 300w, https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/anwb-logo-groot-200x125.png 200w, https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/anwb-logo-groot.png 400w" sizes="(max-width: 102px) 100vw, 102px" /> <img class="alignnone wp-image-553" src="http://template.friks.it/friksbeheer/wp-content/uploads/2018/01/wi-fi-zwart-300x192.png" alt="" width="100" height="64" srcset="https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/wi-fi-zwart-300x192.png 300w, https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/wi-fi-zwart-768x493.png 768w, https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/wi-fi-zwart-1024x657.png 1024w, https://www.grote-wielen.nl/friksbeheer/wp-content/uploads/2018/01/wi-fi-zwart-200x128.png 200w" sizes="(max-width: 100px) 100vw, 100px" /></p>
		</div>
	</div>
</div>
<div class="copyright bg-white">
	<div class="container clearfix">
		<div class="left"><span>© 2019 Restaurant De Grote Wielen</span></div>
		<div class="right">
										<ul class="copyright__menu">
				    				        				        <li>
				            <a href="https://www.grote-wielen.nl/sitemap/">Sitemap</a>
				        </li>
				    				        				        <li>
				            <a href="https://www.grote-wielen.nl/over-ons/">Over ons</a>
				        </li>
				    				        				        <li>
				            <a href="https://www.grote-wielen.nl/contact/">Contact</a>
				        </li>
				        			</ul>
									</div>
	</div>
</div>
<script type='text/javascript' src='https://www.grote-wielen.nl/friksbeheer/wp-includes/js/wp-embed.min.js?ver=4.9.10'></script>
</body>
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/


Served from: www.grote-wielen.nl @ 2019-04-04 09:14:20 by W3 Total Cache
-->